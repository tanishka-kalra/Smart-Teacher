#include<iostream>
using namespace std;
int main()
{
string s;
cin>>s;
for(int e=0,f=s.size()-1;e<f;e++,f--)
{
if(s[e]!=s[f])
{
cout<<"Not a palindrome\n";
return 0;
}
}
cout<<"Palindrome\n";
return 0;
}
